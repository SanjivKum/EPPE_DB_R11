set echo on

set echo on

declare
v_max_count number := 0;
 
begin
select max(CUST_DUA_TYPE_CD)+1 into v_max_count
from RFRNC_CUST_DUA_TYPE;
  
--dbms_output.put_line('max value of Funding_Type is  '||v_max_count);

INSERT INTO RFRNC_CUST_DUA_TYPE
(CUST_DUA_TYPE_CD, CUST_DUA_TYPE_DESC, SYS_CREAT_USER_ID, SYS_CREAT_TS, SYS_UPDT_USER_ID, SYS_UPDT_TS, CUST_DUA_TYPE_ABR, CUST_DUA_TYPE_FLAG)
VALUES(v_max_count, 'Healthcare Operations - Nursing Facility Initiative', 'Wube', sysdate, null, null, 'NFI', 'NON-DUA');
 
end;
/

commit;



