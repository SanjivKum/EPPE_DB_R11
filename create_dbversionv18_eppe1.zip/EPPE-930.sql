---------------------------------------------------------------
-- Update the data file code from FU ASS to FUAS for EPPE 930
---------------------------------------------------------------

INSERT
INTO RFRNC_DATA_FIL
  (
    DATA_FIL_CD,
    DATA_FIL_TYPE_CODE,
    DATA_SOR_CD,
    DATA_FIL_JOB_CD,
    DATA_FIL_DESC,
    DATA_FIL_EFCTV_DT,
    DATA_FIL_TRMNT_DT,
    DATA_RPSTRY_CD,
    SYS_CREAT_USER_ID,
    SYS_CREAT_TS,
    SYS_UPDT_USER_ID,
    SYS_UPDT_TS,
    DATA_PRCSR_CD
  )
  VALUES
  (
    'FUAS',
    NULL,
    '0',
    NULL,
    'SPECIAL DATA FILES CREATED BY FU ASSOC.',
    NULL,
    NULL,
    NULL,
    'RELEASE-10.0',
    sysdate,
    '',
    '',
    NULL
  );

UPDATE DUA_DATA_FIL
SET DATA_FL_CD     ='FUAS',
  SYS_UPDT_USER_ID ='RELEASE-10.0 Script',
  SYS_UPDT_TS      = sysdate
WHERE DATA_FL_CD   = 'FU ASS';

UPDATE DATA_FIL_PRVCY
SET DATA_FIL_CD    ='FUAS',
  SYS_UPDT_USER_ID ='RELEASE-10.0 Script',
  SYS_UPDT_TS      = sysdate
WHERE DATA_FIL_CD  = 'FU ASS';

UPDATE DATA_FIL_ORDR
SET DATA_FIL_CD    ='FUAS',
  SYS_UPDT_USER_ID ='RELEASE-10.0 Script',
  SYS_UPDT_TS      = sysdate
WHERE DATA_FIL_CD  = 'FU ASS';

DELETE FROM RFRNC_DATA_FIL WHERE DATA_FIL_CD = 'FU ASS';

Commit;
